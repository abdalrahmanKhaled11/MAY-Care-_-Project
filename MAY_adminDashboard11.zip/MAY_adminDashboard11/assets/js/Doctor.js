const firebaseConfig = {
    apiKey: "AIzaSyAwP4RbVmDFTMVIqUwursnhVGLO15kPNCA",
    authDomain: "maycare-m9595.firebaseapp.com",
    databaseURL: "https://maycare-m9595-default-rtdb.firebaseio.com",
    projectId: "maycare-m9595",
    storageBucket: "maycare-m9595.appspot.com",
    messagingSenderId: "809066764336",
    appId: "1:809066764336:web:90d7e320de189a875e35f5"
};

// Initialize Firebase if not already initialized
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const db = firebase.database(); // Reference to Firebase Realtime Database

// Load doctors from Firebase and populate the table
async function loadDoctors() {
    const tableBody = document.getElementById('doctorsTableBody');
    try {
        const usersRef = db.ref('Doctors');
        usersRef.on('value', (snapshot) => {
            tableBody.innerHTML = ''; // Clear existing table rows
            snapshot.forEach((childSnapshot) => {
                const userData = childSnapshot.val();
                const row = `
                    <tr>
                        <td>${userData.id || 'N/A'}</td>
                        <td>${userData.name || 'N/A'}</td>
                        <td>${userData.age || 'N/A'}</td>
                        <td>${userData.gender || 'N/A'}</td>
                        <td>${userData.email || 'N/A'}</td>
                        <td>${userData.phone || 'N/A'}</td>
                        <td>${userData.department || 'N/A'}</td>
                        <td class="action-buttons">
                            <button class="edit-btn" onclick="openEditDoctorModal('${childSnapshot.key}', '${userData.name}', ${userData.age}, '${userData.gender}', '${userData.email}', '${userData.phone}', '${userData.department}')">Edit</button>
                            <button class="delete-btn" onclick="deleteDoctor('${childSnapshot.key}')">Delete</button>
                        </td>
                    </tr>
                `;
                tableBody.innerHTML += row; // Add new row to the table
            });
        });
    } catch (error) {
        console.error('Error loading doctors:', error);
    }
}

// Open modal for adding a new doctor
function openAddDoctorModal() {
    document.getElementById('doctorKey').value = '';
    document.getElementById('doctorName').value = '';
    document.getElementById('doctorAge').value = '';
    document.getElementById('doctorGender').value = '';
    document.getElementById('doctorEmail').value = '';
    document.getElementById('doctorPhone').value = '';
    document.getElementById('doctorDepartment').value = '';
    document.getElementById('modalTitle').textContent = 'Add New Doctor';
    document.getElementById('doctorModal').setAttribute('aria-hidden', 'false');
}

// Open modal for editing an existing doctor
function openEditDoctorModal(key, name, age, gender, email, phone, department) {
    document.getElementById('doctorKey').value = key;
    document.getElementById('doctorName').value = name || '';
    document.getElementById('doctorAge').value = age || '';
    document.getElementById('doctorGender').value = gender || '';
    document.getElementById('doctorEmail').value = email || '';
    document.getElementById('doctorPhone').value = phone || '';
    document.getElementById('doctorDepartment').value = department || '';
    document.getElementById('modalTitle').textContent = 'Edit Doctor';
    document.getElementById('doctorModal').setAttribute('aria-hidden', 'false');
}

// Handle form submission for adding/editing a doctor
async function handleDoctorSubmit(event) {
    event.preventDefault();

    const name = document.getElementById('doctorName').value.trim();
    const age = parseInt(document.getElementById('doctorAge').value.trim());
    const gender = document.getElementById('doctorGender').value.trim();
    const email = document.getElementById('doctorEmail').value.trim();
    const phone = document.getElementById('doctorPhone').value.trim();
    const department = document.getElementById('doctorDepartment').value.trim();

    // Validate input fields
    if (!name || isNaN(age) || !gender || !email || !phone || !department) {
        alert('Please fill in all required fields!');
        return;
    }

    const doctorKey = document.getElementById('doctorKey').value;
    const doctorData = {
        name,
        age,
        gender,
        email,
        phone,
        department
    };

    try {
        if (doctorKey) {
            // Update existing doctor
            await db.ref(`Doctors/${doctorKey}`).update(doctorData);
            alert('Doctor updated successfully!');
        } else {
            // Add new doctor with a unique ID
            const newId = (await db.ref('Doctors').once('value')).numChildren() + 1;
            doctorData.id = newId;
            await db.ref(`Doctors/${newId}`).set(doctorData);
            alert('Doctor added successfully!');
        }
        closeModal(); // Close modal after successful operation
    } catch (error) {
        console.error('Error saving doctor data:', error);
        alert('Failed to save doctor data.');
    }
}

// Close the modal
function closeModal() {
    document.getElementById('doctorModal').setAttribute('aria-hidden', 'true');
}

// Search doctors by name or ID
function searchDoctors() {
    const searchValue = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#doctorsTableBody tr');

    rows.forEach((row) => {
        const name = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
        const id = row.querySelector('td:nth-child(1)').textContent.toLowerCase();

        // Show/hide rows based on search input
        if (name.includes(searchValue) || id.includes(searchValue)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Delete a doctor from Firebase
async function deleteDoctor(key) {
    if (confirm('Are you sure you want to delete this doctor?')) {
        try {
            await db.ref(`Doctors/${key}`).remove();
            alert('Doctor deleted successfully!');
        } catch (error) {
            console.error('Error deleting doctor:', error);
            alert('Failed to delete doctor.');
        }
    }
}

// Initialize event listeners when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const addDoctorBtn = document.getElementById('addDoctorBtn');
    if (addDoctorBtn) {
        addDoctorBtn.addEventListener('click', openAddDoctorModal);
    }

    const doctorForm = document.getElementById('doctorForm');
    if (doctorForm) {
        doctorForm.addEventListener('submit', handleDoctorSubmit);
    }

    loadDoctors(); // Load doctors when the page loads
});