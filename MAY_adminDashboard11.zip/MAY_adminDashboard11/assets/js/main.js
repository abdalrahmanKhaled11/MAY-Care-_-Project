// Initialize Firebase with your config
const firebaseConfig = {
  apiKey: "AIzaSyAwP4RbVmDFTMVIqUwursnhVGLO15kPNCA",
  authDomain: "maycare-m9595.firebaseapp.com",
  databaseURL: "https://maycare-m9595-default-rtdb.firebaseio.com",
  projectId: "maycare-m9595",
  storageBucket: "maycare-m9595.firebasestorage.app",
  messagingSenderId: "809066764336",
  appId: "1:809066764336:web:90d7e320de189a875e35f5",
  measurementId: "G-KCXS3KFG2K"
};

// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

// Get reference to the database
const dbRef = firebase.database().ref();
const auth = firebase.auth();
// Function to update the dashboard counters
function updateDashboardCounters() {
    // Reference to Doctors node
    const doctorsRef = dbRef.child('Doctors');

    // Count doctors
    doctorsRef.once('value')
        .then((snapshot) => {
            let doctorCount = 0;
            snapshot.forEach(() => {
                doctorCount++;
            });
            document.getElementById('doctorsCount').textContent = doctorCount;
        })
        .catch((error) => {
            console.error("Error getting doctors count:", error);
        });

    // Reference to Users node for Patients count
    const usersRef = dbRef.child('Users');
    usersRef.orderByChild('role').equalTo('Patient').once('value')
        .then((snapshot) => {
            let patientCount = 0;
            snapshot.forEach(() => {
                patientCount++;
            });
            document.getElementById('patientsCount').textContent = patientCount;
        })
        .catch((error) => {
            console.error("Error getting patients count:", error);
        });
}


// Call the function when the page loads
document.addEventListener('DOMContentLoaded', () => {
  try {
      updateDashboardCounters();
  } catch (error) {
      console.error('Error initializing counters:', error);
  }
});

// Handle authentication state changes
firebase.auth().onAuthStateChanged((user) => {
  if (user) {
      updateDashboardCounters();
  }
});

// Add real-time listeners for updates
function setupRealTimeListeners() {
  const usersRef = dbRef.child('Users');
  
  usersRef.on('child_added', () => updateDashboardCounters());
  usersRef.on('child_removed', () => updateDashboardCounters());
  usersRef.on('child_changed', () => updateDashboardCounters());
}


// Toggle Sidebar Functionality
document.addEventListener('DOMContentLoaded', () => {
  const toggleButton = document.querySelector('.toggle');
  const sidebar = document.querySelector('.navigation');

  // Add a click event listener to the toggle button
  toggleButton.addEventListener('click', () => {
      // Toggle the 'active' class on the sidebar
      sidebar.classList.toggle('active');
      
      // Optionally, adjust the main content width
      const mainContent = document.querySelector('.main');
      if (mainContent) {
          mainContent.classList.toggle('active');
      }
  });
});
