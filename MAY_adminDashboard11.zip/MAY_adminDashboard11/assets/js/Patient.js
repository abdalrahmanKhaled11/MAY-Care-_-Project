
// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAwP4RbVmDFTMVIqUwursnhVGLO15kPNCA",
    authDomain: "maycare-m9595.firebaseapp.com",
    databaseURL: "https://maycare-m9595-default-rtdb.firebaseio.com",
    projectId: "maycare-m9595",
    storageBucket: "maycare-m9595.appspot.com",
    messagingSenderId: "809066764336",
    appId: "1:809066764336:web:90d7e320de189a875e35f5"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const db = firebase.database();

// Load patients from Firebase
async function loadPatients() {
    const tableBody = document.getElementById('patientsTableBody');
    try {
        const usersRef = db.ref('Users');
        usersRef.on('value', (snapshot) => {
            tableBody.innerHTML = '';
            snapshot.forEach((childSnapshot) => {
                const userData = childSnapshot.val();
                if (userData.role === 'Patient') {
                    const row = `
                <tr>
                    <td>${userData.name || ''}</td>
                    <td>${userData.age || ''}</td>
                    <td>${userData.gender || ''}</td>
                    <td>${userData.email || ''}</td>
                    <td>${userData.phone || ''}</td>
                    <td>${userData.id || ''}</td>
                    <td class="action-buttons">
                        <button class="edit-btn" onclick="openEditPatientModal('${childSnapshot.key}', '${userData.name}', ${userData.age}, '${userData.gender}', '${userData.email}', '${userData.phone}', '${userData.id}')">Edit</button>
                        <button class="delete-btn" onclick="deletePatient('${childSnapshot.key}')">Delete</button>
                    </td>
                </tr>
            `;
                    tableBody.innerHTML += row;
                }
            });
        });
    } catch (error) {
        console.error('Error loading patients:', error);
    }
}



// Open the modal for adding a new patient
function openAddPatientModal() {
    document.getElementById('modalTitle').textContent = 'Add New Patient';
    document.getElementById('patientId').value = '';
    document.getElementById('patientForm').reset();
    document.getElementById('patientModal').setAttribute('aria-hidden', 'false');
}

// Open the modal for editing a patient
function openEditPatientModal(id, name, age, gender, email, phone, userId) {
    document.getElementById('modalTitle').textContent = 'Edit Patient';
    document.getElementById('patientId').value = id;
    document.getElementById('patientName').value = name;
    document.getElementById('patientAge').value = age;
    document.getElementById('patientGender').value = gender;
    document.getElementById('patientEmail').value = email;
    document.getElementById('patientPhone').value = phone;
    document.getElementById('patientIdField').value = userId;
    document.getElementById('patientModal').setAttribute('aria-hidden', 'false');
}

// Close the modal
function closeModal() {
    document.getElementById('patientModal').setAttribute('aria-hidden', 'true');
}

// Save patient data to Firebase
async function handlePatientSubmit(event) {
    event.preventDefault();

    const patientId = document.getElementById('patientId').value;
    const patientData = {
        name: document.getElementById('patientName').value,
        age: parseInt(document.getElementById('patientAge').value),
        gender: document.getElementById('patientGender').value,
        email: document.getElementById('patientEmail').value,
        phone: document.getElementById('patientPhone').value,
        id: document.getElementById('patientIdField').value,
        role: 'Patient'
    };

    try {
        if (patientId) {
            await db.ref('Users/' + patientId).update(patientData);
            alert('Patient updated successfully!');
        } else {
            await db.ref('Users').push(patientData);
            alert('Patient added successfully!');
        }
        closeModal();
    } catch (error) {
        console.error('Error saving patient:', error);
        alert('Error saving patient data. Check console for details.');
    }
}

// Search functionality
function searchPatients() {
    const searchValue = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#patientsTableBody tr');

    rows.forEach(row => {
        const name = row.cells[0].textContent.toLowerCase();
        const id = row.cells[5].textContent.toLowerCase();

        if (name.includes(searchValue) || id.includes(searchValue)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Delete a patient from Firebase
async function deletePatient(id) {
    if (confirm('Are you sure you want to delete this patient?')) {
        try {
            await db.ref('Users/' + id).remove();
            alert('Patient deleted successfully!');
        } catch (error) {
            console.error('Error deleting patient:', error);
            alert('Error deleting patient. Check console for details.');
        }
    }
}

// Toggle navigation sidebar
const toggle = document.querySelector('.toggle');
const navigation = document.querySelector('.navigation');
const main = document.querySelector('.main');

if (toggle) {
    toggle.onclick = function () {
        navigation.classList.toggle('active');
        main.classList.toggle('active');
    };
}

// Load patients on DOMContentLoaded
document.addEventListener('DOMContentLoaded', loadPatients);



