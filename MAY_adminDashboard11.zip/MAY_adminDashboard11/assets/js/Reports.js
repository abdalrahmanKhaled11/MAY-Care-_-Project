// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyAwP4RbVmDFTMVIqUwursnhVGLO15kPNCA",
    authDomain: "maycare-m9595.firebaseapp.com",
    databaseURL: "https://maycare-m9595-default-rtdb.firebaseio.com",
    projectId: "maycare-m9595",
    storageBucket: "maycare-m9595.firebasestorage.app",
    messagingSenderId: "809066764336",
    appId: "1:809066764336:web:90d7e320de189a875e35f5",
    measurementId: "G-KCXS3KFG2K"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const db = firebase.database();

// DOM Elements
const reportTableBody = document.getElementById("reportsTableBody");
const reportForm = document.getElementById("reportForm");
const reportModal = document.getElementById("addReportModal");
const reportNameInput = document.getElementById("reportName");
const reportTypeDropdown = document.getElementById("reportType");

// Report Types
const reportTypes = {
    "Heart Condition Report": ["Condition Update"],
    "Surgery Report": ["Post-Surgery Summary"],
    "Lab Test Report": ["Lab Results"],
    "Prescription Report": ["Medication Instructions"],
    "Medical History Report": ["Historical Summary"],
    "Follow-Up Report": ["Follow-Up Plan"],
    "Diagnostic Report": ["Diagnosis Details"],
    "Radiology Report": ["Imaging Results"],
    "Cardiology Report": ["Heart Examination Results"],
    "Surgical Notes": ["Procedure Details"]
};

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
    loadReports();
    
    // Form submission event
    reportForm.addEventListener("submit", handleFormSubmit);

    // Report name change event
    reportNameInput.addEventListener("change", () => {
        updateReportTypes(reportNameInput.value);
    });

    // File upload event
    document.getElementById("reportAttachment").addEventListener("change", function(e) {
        const fileName = e.target.files[0] ? e.target.files[0].name : "No file chosen";
        document.getElementById("file-name").textContent = fileName;
    });
});

// Load Reports
function loadReports() {
    const reportsRef = db.ref("Reports");
    reportsRef.on("value", (snapshot) => {
        reportTableBody.innerHTML = "";
        snapshot.forEach((childSnapshot) => {
            const report = childSnapshot.val();
            const row = document.createElement("tr");
            
            row.innerHTML = `
                <td>${report.id || ""}</td>
                <td>${report.reportName || ""}</td>
                <td>${report.doctorId || ""}</td>
                <td>${report.patientId || ""}</td>
                <td>${report.date || ""}</td>
                <td>${report.information || ""}</td>
                <td>${report.attachment || ""}</td>
                <td class="action-buttons">
                    <button class="edit-btn" data-key="${childSnapshot.key}">Edit</button>
                    <button class="delete-btn" data-key="${childSnapshot.key}">Delete</button>
                </td>
            `;

            // Add event listeners to buttons
            const editBtn = row.querySelector('.edit-btn');
            const deleteBtn = row.querySelector('.delete-btn');

            editBtn.addEventListener('click', () => {
                openEditReportModal(childSnapshot.key, report);
            });

            deleteBtn.addEventListener('click', () => {
                deleteReport(childSnapshot.key);
            });

            reportTableBody.appendChild(row);
        });
    });
}

// Update Report Types Dropdown
function updateReportTypes(reportName) {
    reportTypeDropdown.innerHTML = '<option value="">Select Report Type</option>';
    if (reportTypes[reportName]) {
        reportTypes[reportName].forEach(type => {
            const option = document.createElement("option");
            option.value = type;
            option.textContent = type;
            reportTypeDropdown.appendChild(option);
        });
    }
}


// Helper function to clear form fields for Add functionality
function clearFormFields() {
    document.getElementById("reportForm").reset(); // Reset the form fields
    document.getElementById("reportKey").value = ""; // Clear the hidden report key
    document.getElementById("reportId").value = ""; // Clear the hidden report ID
    reportNameInput.value = ""; // Clear report name
    reportTypeDropdown.innerHTML = "<option value=''>Select Report Type</option>"; // Reset report types dropdown
    document.getElementById("doctorName").value = ""; // Clear doctor name
    document.getElementById("patientName").value = ""; // Clear patient name
    document.getElementById("reportDate").value = ""; // Clear report date
    document.getElementById("reportInfo").value = ""; // Clear report information
    document.getElementById("file-name").textContent = "No file chosen"; // Reset file display name
}

// Open Add Report Modal
function openAddReportModal() {
    clearFormFields(); // Clear the form fields
    document.getElementById("modalTitle").textContent = "Add New Report"; // Set the title for Add
    document.getElementById("reportKey").value = ""; // Clear the hidden report key
    document.getElementById("reportId").value = ""; // Clear the hidden report ID
    document.getElementById("file-name").textContent = "No file chosen"; // Reset file display name
    
    // Reset the form to ensure no "Edit" action is carried over
    reportModal.style.display = "flex"; // Show the modal
}

function openEditReportModal(key, report) {
    // Debugging: Ensure the function is being called with correct parameters
    console.log("Editing report:", key, report);

    if (!key || !report) {
        console.error("Invalid key or report object passed to openEditReportModal");
        return;
    }

    document.getElementById("modalTitle").textContent = "Edit Report"; // Set the title for Edit
    document.getElementById("reportKey").value = key; // Set the hidden report key
    document.getElementById("reportId").value = report.id || ""; // Set the hidden report ID
    reportNameInput.value = report.reportName || ""; // Set the report name

    // Update the report types dropdown dynamically
    updateReportTypes(report.reportName);
    reportTypeDropdown.value = report.reportType || ""; // Set the report type

    document.getElementById("doctorName").value = report.doctorId || ""; // Set the doctor name
    document.getElementById("patientName").value = report.patientId || ""; // Set the patient name
    document.getElementById("reportDate").value = report.date || ""; // Set the report date
    document.getElementById("reportInfo").value = report.information || ""; // Set the report information
    document.getElementById("file-name").textContent = report.attachment || "No file chosen"; // Set the attachment name
    
    reportModal.style.display = "flex"; // Show the modal
}

async function handleFormSubmit(event) {
    event.preventDefault();

    const reportKey = document.getElementById("reportKey").value; // Get the report key (if editing)
    const reportId = document.getElementById("reportId").value || await generateReportId(); // Generate or get report ID
    const reportData = {
        id: reportId, // Use the report ID as part of the data
        reportName: reportNameInput.value,
        reportType: reportTypeDropdown.value,
        doctorId: document.getElementById("doctorName").value,
        patientId: document.getElementById("patientName").value,
        date: document.getElementById("reportDate").value,
        information: document.getElementById("reportInfo").value,
        attachment: document.getElementById("file-name").textContent
    };

    try {
        if (reportKey) {
            // Update existing report
            console.log("Updating report:", reportKey, reportData); // Debugging
            await db.ref(`Reports/${reportId}`).update(reportData); // Use the report ID as the key
            alert("Report updated successfully!");
        } else {
            // Add new report
            console.log("Adding new report:", reportData); // Debugging
            await db.ref(`Reports/${reportId}`).set(reportData); // Use the report ID as the key
            alert("Report added successfully!");
        }
        closeModal();
    } catch (error) {
        console.error("Error saving report:", error);
        alert("Error saving report. Please try again.");
    }
}

// Generate Report ID
async function generateReportId() {
    const reportsRef = db.ref("Reports");
    const snapshot = await reportsRef.once("value");
    const reportCount = snapshot.numChildren() + 1; // Increment based on the number of reports
    return reportCount.toString(); // Use the count as the report ID
}


// Delete Report
function deleteReport(key) {
    if (confirm("Are you sure you want to delete this report?")) {
        db.ref(`Reports/${key}`).remove()
            .then(() => alert("Report deleted successfully!"))
            .catch(error => {
                console.error("Error deleting report:", error);
                alert("Error deleting report. Please try again.");
            });
    }
}

// Close Modal
function closeModal() {
    reportModal.style.display = "none";
    clearFormFields();
}

// Make functions available globally
window.openAddReportModal = openAddReportModal;
window.closeModal = closeModal;


   // Logout Function
   function logout() {
    sessionStorage.removeItem('doctorId');
    window.location.href = 'Login.html';
}

// Open Add Report Modal
function openAddReportModal() {
    document.getElementById('addReportModal').style.display = 'flex';
}

// Close Modal
function closeModal() {
    document.getElementById('addReportModal').style.display = 'none';
}

// Handle File Upload Display
document.getElementById('reportAttachment').addEventListener('change', function (e) {
    const fileName = e.target.files[0] ? e.target.files[0].name : 'No file chosen';
    document.getElementById('file-name').textContent = fileName;
});